import { z } from "zod";

export const departments = [
  "IT",
  "HR",
  "Finance",
  "Sales",
  "Operations",
];

export const employmentTypes = [
  "FullTime",
  "PartTime",
  "Contract",
  "Intern",
];

export const employmentStatuses = [
  "Active",
  "OnLeave",
  "Inactive",
];

export function getLocalDateString(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

export function getMinimumJoiningDate() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - 7);

  return getLocalDateString(date);
}

const nameSchema = z
  .string()
  .trim()
  .min(2, "Name must contain at least 2 characters.")
  .max(50, "Name cannot exceed 50 characters.")
  .regex(
    /^\p{L}+(?:[ '-]\p{L}+)*$/u,
    "Enter a valid name."
  );

export const employeeSchema = z
  .object({
    firstName: nameSchema,

    lastName: nameSchema,

    workEmail: z
      .string()
      .trim()
      .min(1, "Work email is required.")
      .email("Enter a valid work email.")
      .max(254, "Email cannot exceed 254 characters."),

    phoneNumber: z
      .string()
      .trim()
      .regex(
        /^[6-9]\d{9}$/,
        "Enter a valid 10-digit mobile number."
      ),

    department: z
      .string()
      .refine(
        (value) => departments.includes(value),
        "Select a valid department."
      ),

    jobTitle: z
      .string()
      .trim()
      .min(1, "Job title is required.")
      .max(100, "Job title cannot exceed 100 characters."),

    employmentType: z
      .string()
      .refine(
        (value) => employmentTypes.includes(value),
        "Select a valid employment type."
      ),

    joiningDate: z
      .string()
      .min(1, "Joining date is required.")
      .refine((value) => {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
          return false;
        }

        const date = new Date(`${value}T00:00:00`);

        return (
          !Number.isNaN(date.getTime()) &&
          getLocalDateString(date) === value
        );
      }, "Enter a valid joining date.")
      .refine(
        (value) => value >= getMinimumJoiningDate(),
        "Joining date cannot be earlier than 7 days ago."
      ),

    employmentStatus: z
      .string()
      .refine(
        (value) => employmentStatuses.includes(value),
        "Select a valid status."
      ),

    workLocation: z
      .string()
      .trim()
      .min(1, "Work location is required.")
      .max(100, "Work location cannot exceed 100 characters."),

    address: z
      .string()
      .max(300, "Address cannot exceed 300 characters."),

    password: z
      .string()
      .min(8, "Password must contain at least 8 characters.")
      .max(72, "Password cannot exceed 72 characters.")
      .regex(/[A-Z]/, "Include an uppercase letter.")
      .regex(/[a-z]/, "Include a lowercase letter.")
      .regex(/[0-9]/, "Include a number.")
      .regex(/[^A-Za-z0-9]/, "Include a special character."),

    confirmPassword: z
      .string()
      .min(1, "Confirm the password."),
  })
  .refine((values) => values.password === values.confirmPassword, {
    message: "Passwords do not match.",
    path: ["confirmPassword"],
  });
